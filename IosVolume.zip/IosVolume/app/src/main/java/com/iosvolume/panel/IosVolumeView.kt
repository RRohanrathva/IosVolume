package com.iosvolume.panel

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.view.View
import android.view.animation.DecelerateInterpolator

/**
 * iOS-style vertical volume capsule: translucent dark track, white fill rising from the
 * bottom, speaker glyph at the bottom that flips colour where the fill passes over it.
 */
class IosVolumeView(context: Context) : View(context) {

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC2C2C2E.toInt() }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val clip = Path()
    private val rect = RectF()

    private var shown = 0f
    private var animator: ValueAnimator? = null

    private var iconRes = 0
    // Two separate instances: a single VectorDrawable can't hold two tints in one frame.
    private var iconLight: Drawable? = null
    private var iconDark: Drawable? = null

    fun setLevel(fraction: Float, muted: Boolean, animate: Boolean) {
        val target = fraction.coerceIn(0f, 1f)
        val res = when {
            muted || target <= 0f -> R.drawable.ic_volume_off
            target < 0.5f -> R.drawable.ic_volume_down
            else -> R.drawable.ic_volume_up
        }
        if (res != iconRes) {
            iconRes = res
            iconLight = context.getDrawable(res)?.mutate()?.also { it.setTint(0xFFB5B5BA.toInt()) }
            iconDark = context.getDrawable(res)?.mutate()?.also { it.setTint(0xFF3A3A3C.toInt()) }
        }
        animator?.cancel()
        if (!animate) {
            shown = target
            invalidate()
            return
        }
        animator = ValueAnimator.ofFloat(shown, target).apply {
            duration = 140
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                shown = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        rect.set(0f, 0f, w, h)
        clip.reset()
        clip.addRoundRect(rect, w / 2f, w / 2f, Path.Direction.CW)

        canvas.drawPath(clip, trackPaint)

        canvas.save()
        canvas.clipPath(clip)

        val top = h - h * shown
        canvas.drawRect(0f, top, w, h, fillPaint)

        val size = (w * 0.46f).toInt()
        val left = ((w - size) / 2f).toInt()
        val iconTop = (h - w * 0.30f - size).toInt()

        iconLight?.apply {
            setBounds(left, iconTop, left + size, iconTop + size)
            draw(canvas)
        }
        canvas.save()
        canvas.clipRect(0f, top, w, h)
        iconDark?.apply {
            setBounds(left, iconTop, left + size, iconTop + size)
            draw(canvas)
        }
        canvas.restore()

        canvas.restore()
    }
}
