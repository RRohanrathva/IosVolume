package com.iosvolume.panel

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat

/**
 * Intercepts the hardware volume keys (so the stock Android panel never appears),
 * changes the volume itself, and shows the iOS-style capsule as an accessibility overlay.
 * TYPE_ACCESSIBILITY_OVERLAY needs no "draw over other apps" permission.
 */
class VolumeAccessibilityService : AccessibilityService() {

    private lateinit var audio: AudioManager
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var hud: IosVolumeView? = null
    private var attached = false
    private var hiding = false

    private val hideRunnable = Runnable { hideHud() }

    // Covers volume changes that don't come from the hardware keys (Bluetooth, apps...).
    private val volumeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val stream = intent.getIntExtra(EXTRA_STREAM_TYPE, -1)
            if (stream == AudioManager.STREAM_MUSIC ||
                stream == AudioManager.STREAM_VOICE_CALL ||
                stream == AudioManager.STREAM_RING
            ) showHud(stream)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        ContextCompat.registerReceiver(
            this, volumeReceiver, IntentFilter(ACTION_VOLUME_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false

        // Act on DOWN (including key-repeat while held); swallow UP so the system ignores both.
        if (event.action == KeyEvent.ACTION_DOWN) {
            val stream = targetStream()
            val direction =
                if (code == KeyEvent.KEYCODE_VOLUME_UP) AudioManager.ADJUST_RAISE
                else AudioManager.ADJUST_LOWER
            try {
                audio.adjustStreamVolume(stream, direction, 0) // flags = 0 -> no system UI
            } catch (_: SecurityException) {
                return false // e.g. Do Not Disturb restrictions: let the system handle it
            }
            showHud(stream)
        }
        return true
    }

    private fun targetStream(): Int = when (audio.mode) {
        AudioManager.MODE_IN_CALL, AudioManager.MODE_IN_COMMUNICATION -> AudioManager.STREAM_VOICE_CALL
        else -> AudioManager.STREAM_MUSIC
    }

    private fun showHud(stream: Int) {
        val min = audio.getStreamMinVolume(stream)
        val max = audio.getStreamMaxVolume(stream)
        val cur = audio.getStreamVolume(stream)
        val fraction = if (max > min) (cur - min).toFloat() / (max - min) else 0f
        val muted = audio.isStreamMute(stream) || cur <= min

        val view = hud ?: IosVolumeView(this).also { hud = it }
        hiding = false

        if (!attached) {
            view.setLevel(fraction, muted, animate = false)
            view.alpha = 0f
            view.translationX = -dp(12).toFloat()
            try {
                wm.addView(view, layoutParams())
            } catch (_: Exception) {
                return
            }
            attached = true
            view.animate().alpha(1f).translationX(0f).setDuration(180).start()
        } else {
            view.animate().cancel()
            view.alpha = 1f
            view.translationX = 0f
            view.setLevel(fraction, muted, animate = true)
        }

        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, HIDE_DELAY_MS)
    }

    private fun hideHud() {
        val view = hud ?: return
        if (!attached) return
        hiding = true
        view.animate().alpha(0f).translationX(-dp(12).toFloat()).setDuration(220)
            .withEndAction {
                if (hiding) removeHud()
            }.start()
    }

    private fun removeHud() {
        val view = hud ?: return
        if (attached) {
            try {
                wm.removeView(view)
            } catch (_: Exception) {
            }
            attached = false
        }
        hiding = false
    }

    private fun layoutParams() = WindowManager.LayoutParams(
        dp(56), dp(176),
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.START or Gravity.CENTER_VERTICAL
        x = dp(14)
        title = "IosVolumeHud"
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(hideRunnable)
        try {
            unregisterReceiver(volumeReceiver)
        } catch (_: Exception) {
        }
        hud?.animate()?.cancel()
        removeHud()
        super.onDestroy()
    }

    private companion object {
        const val HIDE_DELAY_MS = 1800L
        const val ACTION_VOLUME_CHANGED = "android.media.VOLUME_CHANGED_ACTION"
        const val EXTRA_STREAM_TYPE = "android.media.EXTRA_VOLUME_STREAM_TYPE"
    }
}
