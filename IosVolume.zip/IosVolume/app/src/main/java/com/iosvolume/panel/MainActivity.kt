package com.iosvolume.panel

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.WindowInsets
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = dp(24)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFFF2F2F7.toInt())
            setPadding(pad, pad, pad, pad)
            setOnApplyWindowInsetsListener { v, insets ->
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                v.setPadding(pad + bars.left, pad + bars.top, pad + bars.right, pad + bars.bottom)
                insets
            }
        }

        root.addView(TextView(this).apply {
            text = "iOS Volume"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF1C1C1E.toInt())
        })

        status = TextView(this).apply {
            textSize = 17f
            setPadding(0, dp(16), 0, dp(16))
        }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "1. Enable in Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        root.addView(Button(this).apply {
            text = "Toggle greyed out? Open App info"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        })

        root.addView(TextView(this).apply {
            text = "Steps:\n" +
                "1. Open Accessibility settings, find \"iOS Volume\" and turn it on.\n" +
                "2. If the switch is greyed out (Android 13+ sideloaded apps): App info > ⋮ menu > " +
                "Allow restricted settings, then try again.\n" +
                "3. Press the volume buttons. The iOS-style panel appears on the left edge."
            textSize = 15f
            setTextColor(0xFF48484A.toInt())
            setPadding(0, dp(20), 0, 0)
        })

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (isServiceEnabled()) {
            status.text = "Status: ON ✓"
            status.setTextColor(0xFF248A3D.toInt())
        } else {
            status.text = "Status: OFF"
            status.setTextColor(0xFFD70015.toInt())
        }
    }

    private fun isServiceEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName }
    }
}
