# iOS Volume (Android 12 → latest)

Replaces the stock Android volume panel with an iOS-style vertical capsule on the left edge.

## Build
1. Open the `IosVolume` folder in Android Studio (Ladybug or newer) and let Gradle sync.
2. Run on a phone, or Build > Build APK(s).

## Enable
1. Open the app, tap "Enable in Accessibility settings", turn on "iOS Volume".
2. Android 13+ sideloaded APK and the switch is greyed out: App info > ⋮ > Allow restricted settings.
3. Press the volume buttons.

## How it works
- An AccessibilityService (`flagRequestFilterKeyEvents`) catches the volume keys, consumes them
  (so the system panel never shows) and calls `AudioManager.adjustStreamVolume(..., flags = 0)`.
- The capsule is drawn by `IosVolumeView` in a `TYPE_ACCESSIBILITY_OVERLAY` window, so no
  "display over other apps" permission is needed.
- Volume changes from Bluetooth/apps also show the capsule (via `VOLUME_CHANGED_ACTION`), but
  the stock panel may appear for those too, since only key presses can be intercepted.

## Known limits
- Volume keys are consumed everywhere, so "volume key = camera shutter" won't work while it's on.
- Controls the media stream (or call stream during a call). Ringer volume is not handled.
- Accessibility apps used this way are generally not accepted on Google Play; this is for personal use.
